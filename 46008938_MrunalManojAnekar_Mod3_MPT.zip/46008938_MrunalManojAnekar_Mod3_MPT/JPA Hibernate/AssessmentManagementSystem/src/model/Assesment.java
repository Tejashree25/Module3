package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Assesment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO) 	
	int details_id;
	String trainee_name;
	String module_name;
	int Mpt_marks;
	int mtt_marks;
	int assignment_marks;
	int total;
	
	public Assesment() {}

	public Assesment(int details_id, String trainee_name, String module_name, int mpt_marks, int mtt_marks,
			int assignment_marks, int total) {
		super();
		this.details_id = details_id;
		this.trainee_name = trainee_name;
		this.module_name = module_name;
		Mpt_marks = mpt_marks;
		this.mtt_marks = mtt_marks;
		this.assignment_marks = assignment_marks;
		this.total = total;
	}
	
	public Assesment(String trainee_name, String module_name, int mpt_marks, int mtt_marks,
			int assignment_marks, int total) {
		super();
		this.trainee_name = trainee_name;
		this.module_name = module_name;
		Mpt_marks = mpt_marks;
		this.mtt_marks = mtt_marks;
		this.assignment_marks = assignment_marks;
		this.total = total;
	}

	public int getDetails_id() {
		return details_id;
	}

	public void setDetails_id(int details_id) {
		this.details_id = details_id;
	}

	public String getTrainee_name() {
		return trainee_name;
	}

	public void setTrainee_name(String trainee_name) {
		this.trainee_name = trainee_name;
	}

	public String getModule_name() {
		return module_name;
	}

	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}

	public int getMpt_marks() {
		return Mpt_marks;
	}

	public void setMpt_marks(int mpt_marks) {
		Mpt_marks = mpt_marks;
	}

	public int getMtt_marks() {
		return mtt_marks;
	}

	public void setMtt_marks(int mtt_marks) {
		this.mtt_marks = mtt_marks;
	}

	public int getAssignment_marks() {
		return assignment_marks;
	}

	public void setAssignment_marks(int assignment_marks) {
		this.assignment_marks = assignment_marks;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Assesment [details_id=" + details_id + ", trainee_name=" + trainee_name + ", module_name=" + module_name
				+ ", Mpt_marks=" + Mpt_marks + ", mtt_marks=" + mtt_marks + ", assignment_marks=" + assignment_marks
				+ ", total=" + total + "]";
	}
	
	
	
}	