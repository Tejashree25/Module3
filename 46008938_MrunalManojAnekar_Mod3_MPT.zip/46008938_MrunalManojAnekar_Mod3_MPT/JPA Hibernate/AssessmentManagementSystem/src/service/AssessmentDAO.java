package service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Assesment;

public class AssessmentDAO {

   public static void main( String[ ] args ) {
   
      EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "Eclipselink_JPA" );
      
      EntityManager entitymanager = emfactory.createEntityManager( );
      entitymanager.getTransaction( ).begin( );

      Assesment as = new Assesment( ); 
      as.setDetails_id(101);
      as.setTrainee_name("Mrunal");
      as.setModule_name("Mod1");
      as.setMpt_marks(60);
      as.setMtt_marks(15);
      as.setAssignment_marks(10);
      as.setTotal(85);
      
      entitymanager.persist( as );
      entitymanager.getTransaction( ).commit( );

      entitymanager.close( );
      emfactory.close( );
   }
}