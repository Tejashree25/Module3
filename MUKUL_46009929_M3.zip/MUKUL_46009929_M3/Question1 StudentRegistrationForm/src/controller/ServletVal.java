package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletVal
 */
@WebServlet("/ServletVal")
public class ServletVal extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletVal() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String mob = request.getParameter("numb");
		String per = request.getParameter("per");
		boolean fl = false;
		if(mob.length() == 10)
		{char[] ch = mob.toCharArray();
			for(int i = 0;i<10;i++)
			{
				
				if(Character.isDigit(ch[i]))
				{
					fl = true;
				}
			}
		}
		
		if(Double.parseDouble(per) > 100.0 && Double.parseDouble(per) < 0.0)
		{
			fl = false;
		}
		
		if(fl)
		{
			response.sendRedirect("Success.jsp?per="+per);
			//response.getWriter().print("Data Has Been Successfully Stored. Your percentage are :" + mark );
		}
}
	}
